import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  authenticateToken, 
  requireRole, 
  hashPassword, 
  verifyPassword, 
  generateTokens,
  rateLimitAuth 
} from "./middleware/auth";
import { 
  securityHeaders, 
  generalRateLimit, 
  authRateLimit, 
  adminRateLimit,
  sanitizeInput,
  auditLogger,
  csrfProtection,
  generateCSRFToken,
  accountLockoutProtection 
} from "./middleware/security";
import { 
  subdomainRouter, 
  enforceSubdomainAccess, 
  getSubdomainContext 
} from "./middleware/subdomain";
import { 
  insertUserSchema, 
  insertAppointmentSchema, 
  insertSupportTicketSchema, 
  insertNotificationSchema,
  insertRoleSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(securityHeaders);
  app.use(sanitizeInput);
  app.use(auditLogger);
  app.use(generalRateLimit);
  app.use(generateCSRFToken);
  
  // Subdomain routing
  app.use(subdomainRouter);
  
  // Auth middleware (Replit Auth)
  await setupAuth(app);

  // CSRF token endpoint
  app.get('/api/csrf-token', (req, res) => {
    res.json({ csrfToken: res.locals.csrfToken });
  });

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User registration endpoint
  app.post('/api/auth/register', authRateLimit, accountLockoutProtection, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email!);
      if (existingUser) {
        return res.status(409).json({ error: 'User already exists' });
      }

      // Hash password
      const { hash, salt } = await hashPassword(userData.passwordHash!);
      
      // Create user with pending status
      const user = await storage.createUser({
        ...userData,
        passwordHash: hash,
        salt,
        status: 'pending',
        createdByIp: req.ip as any,
      });

      await storage.logSecurityEvent({
        userId: user.id,
        sessionId: req.sessionID,
        action: 'USER_REGISTRATION',
        resource: 'users',
        details: { email: user.email },
        ipAddress: req.ip as any,
        userAgent: req.headers['user-agent'] || '',
        success: true,
        riskScore: 1,
      });

      res.status(201).json({ 
        message: 'Registration successful. Awaiting admin approval.',
        userId: user.id 
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(400).json({ error: 'Registration failed' });
    }
  });

  // JWT-based login (for non-Replit auth scenarios)
  app.post('/api/auth/login-jwt', authRateLimit, accountLockoutProtection, async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      if (user.status !== 'active') {
        return res.status(403).json({ error: 'Account not activated' });
      }

      const validPassword = await verifyPassword(password, user.passwordHash!);
      if (!validPassword) {
        await storage.incrementFailedLogin(user.id);
        
        // Lock account after 5 failed attempts
        if ((user.failedLoginAttempts || 0) >= 4) {
          const lockUntil = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes
          await storage.lockUser(user.id, lockUntil);
        }

        return res.status(401).json({ error: 'Invalid credentials' });
      }

      // Reset failed login attempts on successful login
      await storage.resetFailedLogin(user.id);
      
      // Update last login
      await storage.updateUser(user.id, {
        lastLogin: new Date(),
        lastLoginIp: req.ip as any,
      });

      // Generate tokens
      const tokens = generateTokens({
        userId: user.id,
        email: user.email!,
        role: user.roleId?.toString() || 'user',
      });

      // Log successful login
      await storage.logSecurityEvent({
        userId: user.id,
        sessionId: req.sessionID,
        action: 'LOGIN_SUCCESS',
        resource: 'auth',
        details: { method: 'jwt' },
        ipAddress: req.ip as any,
        userAgent: req.headers['user-agent'] || '',
        success: true,
        riskScore: 0,
      });

      res.json({ ...tokens, user });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  // Admin routes
  app.use('/api/admin', adminRateLimit, isAuthenticated, requireRole(['admin', 'superadmin']));
  
  // User management (Admin only)
  app.get('/api/admin/users', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  app.patch('/api/admin/users/:id/status', csrfProtection, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      await storage.updateUserStatus(id, status);
      
      await storage.logSecurityEvent({
        userId: (req as any).user.claims.sub,
        sessionId: req.sessionID,
        action: 'USER_STATUS_CHANGE',
        resource: `users/${id}`,
        details: { newStatus: status },
        ipAddress: req.ip as any,
        userAgent: req.headers['user-agent'] || '',
        success: true,
        riskScore: 2,
      });

      res.json({ message: 'User status updated' });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user status' });
    }
  });

  // Role management (Admin only)
  app.get('/api/admin/roles', async (req, res) => {
    try {
      const roles = await storage.getAllRoles();
      res.json(roles);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch roles' });
    }
  });

  app.post('/api/admin/roles', csrfProtection, async (req, res) => {
    try {
      const roleData = insertRoleSchema.parse(req.body);
      const role = await storage.createRole(roleData);
      res.status(201).json(role);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create role' });
    }
  });

  // Appointment management
  app.get('/api/appointments', isAuthenticated, async (req, res) => {
    try {
      const user = (req as any).user;
      const isAdmin = ['admin', 'superadmin'].includes(user.role);
      
      const appointments = isAdmin 
        ? await storage.getAllAppointments()
        : await storage.getAppointmentsByUser(user.claims.sub);
      
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch appointments' });
    }
  });

  app.post('/api/appointments', isAuthenticated, csrfProtection, async (req, res) => {
    try {
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId: (req as any).user.claims.sub,
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create appointment' });
    }
  });

  app.patch('/api/appointments/:id', isAuthenticated, csrfProtection, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const appointment = await storage.updateAppointment(parseInt(id), updates);
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update appointment' });
    }
  });

  // Support ticket management
  app.get('/api/tickets', isAuthenticated, async (req, res) => {
    try {
      const user = (req as any).user;
      const isAdmin = ['admin', 'superadmin'].includes(user.role);
      
      const tickets = isAdmin 
        ? await storage.getAllTickets()
        : await storage.getTicketsByUser(user.claims.sub);
      
      res.json(tickets);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch tickets' });
    }
  });

  app.post('/api/tickets', isAuthenticated, csrfProtection, async (req, res) => {
    try {
      const ticketData = insertSupportTicketSchema.parse({
        ...req.body,
        userId: (req as any).user.claims.sub,
      });
      
      const ticket = await storage.createTicket(ticketData);
      res.status(201).json(ticket);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create ticket' });
    }
  });

  app.patch('/api/tickets/:id', isAuthenticated, csrfProtection, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const ticket = await storage.updateTicket(parseInt(id), updates);
      res.json(ticket);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update ticket' });
    }
  });

  // Notification management
  app.get('/api/notifications', async (req, res) => {
    try {
      const notifications = await storage.getActiveNotifications();
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch notifications' });
    }
  });

  app.post('/api/admin/notifications', isAuthenticated, requireRole(['admin', 'superadmin']), csrfProtection, async (req, res) => {
    try {
      const notificationData = insertNotificationSchema.parse({
        ...req.body,
        createdBy: (req as any).user.claims.sub,
      });
      
      const notification = await storage.createNotification(notificationData);
      res.status(201).json(notification);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create notification' });
    }
  });

  // Security audit logs (Admin only)
  app.get('/api/admin/audit-logs', isAuthenticated, requireRole(['admin', 'superadmin']), async (req, res) => {
    try {
      const { userId, limit } = req.query;
      const logs = await storage.getAuditLogs(
        userId as string, 
        limit ? parseInt(limit as string) : undefined
      );
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch audit logs' });
    }
  });

  // User profile management
  app.get('/api/profile', isAuthenticated, async (req, res) => {
    try {
      const userId = (req as any).user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Remove sensitive data
      const { passwordHash, salt, mfaSecret, ...profileData } = user;
      res.json(profileData);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profile' });
    }
  });

  app.patch('/api/profile', isAuthenticated, csrfProtection, async (req, res) => {
    try {
      const userId = (req as any).user.claims.sub;
      const updates = req.body;
      
      // Remove sensitive fields that shouldn't be updated via this endpoint
      delete updates.passwordHash;
      delete updates.salt;
      delete updates.mfaSecret;
      delete updates.roleId;
      delete updates.status;
      
      const user = await storage.updateUser(userId, updates);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });

  // Subdomain-specific routes
  app.get('/api/subdomain/context', (req, res) => {
    const context = getSubdomainContext(req);
    res.json(context);
  });

  const httpServer = createServer(app);
  return httpServer;
}
