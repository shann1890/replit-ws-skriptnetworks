import { type RequestHandler } from "express";

export interface SubdomainConfig {
  subdomain: string;
  allowedRoles: string[];
  redirectPath?: string;
  requireAuth?: boolean;
}

const subdomainConfigs: SubdomainConfig[] = [
  {
    subdomain: 'admin',
    allowedRoles: ['admin', 'superadmin'],
    requireAuth: true,
    redirectPath: '/dashboard'
  },
  {
    subdomain: 'user',
    allowedRoles: ['user', 'admin', 'superadmin'],
    requireAuth: true,
    redirectPath: '/dashboard'
  },
  {
    subdomain: 'portal',
    allowedRoles: ['user', 'admin', 'superadmin'],
    requireAuth: true,
    redirectPath: '/dashboard'
  },
  {
    subdomain: 'www',
    allowedRoles: ['*'],
    requireAuth: false
  }
];

export const subdomainRouter: RequestHandler = (req, res, next) => {
  const hostname = req.hostname;
  const subdomain = hostname.split('.')[0];
  
  // Default to www if no subdomain or if it's the main domain
  // In Replit environment, always default to www for now
  const normalizedSubdomain = subdomain === hostname || hostname.includes('repl') ? 'www' : subdomain;
  
  const config = subdomainConfigs.find(c => c.subdomain === normalizedSubdomain);
  
  if (!config) {
    // If no specific subdomain config found, default to www config
    const defaultConfig = subdomainConfigs.find(c => c.subdomain === 'www');
    req.subdomainConfig = defaultConfig || subdomainConfigs[0];
    req.currentSubdomain = 'www';
  } else {
    // Set subdomain context
    req.subdomainConfig = config;
    req.currentSubdomain = normalizedSubdomain;
  }

  next();
};

export const enforceSubdomainAccess: RequestHandler = (req, res, next) => {
  const config = req.subdomainConfig;
  const user = req.user;

  if (!config) {
    return res.status(404).json({ error: 'Subdomain configuration not found' });
  }

  // Check if authentication is required
  if (config.requireAuth && !user) {
    return res.status(401).json({ 
      error: 'Authentication required for this subdomain',
      redirectUrl: '/api/login'
    });
  }

  // Check role-based access
  if (user && config.allowedRoles[0] !== '*' && !config.allowedRoles.includes(user.role)) {
    return res.status(403).json({ 
      error: 'Access denied for this subdomain',
      userRole: user.role,
      allowedRoles: config.allowedRoles
    });
  }

  next();
};

export const getSubdomainContext = (req: any): { subdomain: string; config: SubdomainConfig } => {
  return {
    subdomain: req.currentSubdomain || 'www',
    config: req.subdomainConfig || subdomainConfigs.find(c => c.subdomain === 'www')!
  };
};

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      subdomainConfig?: SubdomainConfig;
      currentSubdomain?: string;
    }
  }
}
