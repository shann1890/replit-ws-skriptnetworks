import { type RequestHandler } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { storage } from "../storage";

interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  subdomain?: string;
}

export const JWT_SECRET = process.env.JWT_SECRET || "your_super_secure_jwt_secret_minimum_32_chars";
export const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "your_refresh_token_secret_minimum_32_chars";
export const JWT_ACCESS_EXPIRE = process.env.JWT_ACCESS_EXPIRE || "15m";
export const JWT_REFRESH_EXPIRE = process.env.JWT_REFRESH_EXPIRE || "7d";

export const generateTokens = (payload: JWTPayload) => {
  const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_ACCESS_EXPIRE });
  const refreshToken = jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: JWT_REFRESH_EXPIRE });
  return { accessToken, refreshToken };
};

export const verifyToken = (token: string, secret: string = JWT_SECRET): JWTPayload | null => {
  try {
    return jwt.verify(token, secret) as JWTPayload;
  } catch (error) {
    return null;
  }
};

export const hashPassword = async (password: string): Promise<{ hash: string; salt: string }> => {
  const salt = await bcrypt.genSalt(12);
  const hash = await bcrypt.hash(password, salt);
  return { hash, salt };
};

export const verifyPassword = async (password: string, hash: string): Promise<boolean> => {
  return await bcrypt.compare(password, hash);
};

export const generateMFASecret = (): string => {
  return crypto.randomBytes(32).toString('base64');
};

export const authenticateToken: RequestHandler = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: "Access token required" });
  }

  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }

  // Check if user exists and is active
  const user = await storage.getUser(payload.userId);
  if (!user || user.status !== 'active') {
    return res.status(401).json({ message: "User not found or inactive" });
  }

  // Check if user is locked
  if (user.lockedUntil && new Date() < user.lockedUntil) {
    return res.status(423).json({ message: "Account is locked" });
  }

  // Get user role for authorization
  const userRole = user.roleId ? await storage.getRole(user.roleId) : null;
  const roleName = userRole?.name || 'user';

  req.user = { ...payload, role: roleName, userDetails: user };
  next();
};

export const requireRole = (roles: string[]): RequestHandler => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }

    next();
  };
};

export const requireSubdomain = (allowedSubdomains: string[]): RequestHandler => {
  return (req, res, next) => {
    const subdomain = req.hostname.split('.')[0];
    
    if (!allowedSubdomains.includes(subdomain)) {
      return res.status(403).json({ message: "Access denied for this subdomain" });
    }

    next();
  };
};

// Rate limiting for authentication attempts
const loginAttempts = new Map<string, { count: number; lastAttempt: Date }>();

export const rateLimitAuth: RequestHandler = (req, res, next) => {
  const ip = req.ip;
  const now = new Date();
  const windowMs = 15 * 60 * 1000; // 15 minutes
  const maxAttempts = 5;

  const attempts = loginAttempts.get(ip);
  
  if (attempts) {
    if (now.getTime() - attempts.lastAttempt.getTime() > windowMs) {
      // Reset window
      loginAttempts.set(ip, { count: 1, lastAttempt: now });
    } else if (attempts.count >= maxAttempts) {
      return res.status(429).json({ 
        message: "Too many authentication attempts. Please try again later." 
      });
    } else {
      attempts.count++;
      attempts.lastAttempt = now;
    }
  } else {
    loginAttempts.set(ip, { count: 1, lastAttempt: now });
  }

  next();
};

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: JWTPayload & { userDetails?: any };
    }
  }
}
