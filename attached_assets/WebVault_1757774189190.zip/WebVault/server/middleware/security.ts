import { type RequestHandler } from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { storage } from "../storage";
import { randomBytes } from "crypto";

// Security headers middleware
export const securityHeaders = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true,
  },
});

// General rate limiting
export const generalRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limit each IP to 1000 requests per windowMs
  message: {
    error: "Too many requests from this IP, please try again later."
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Strict rate limiting for authentication endpoints
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: {
    error: "Too many authentication attempts, please try again later."
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Admin endpoint rate limiting
export const adminRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs for admin endpoints
  message: {
    error: "Too many admin requests, please try again later."
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Input sanitization middleware
export const sanitizeInput: RequestHandler = (req, res, next) => {
  const sanitize = (obj: any): any => {
    if (typeof obj === 'string') {
      // Remove potential XSS scripts
      return obj.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
    }
    if (Array.isArray(obj)) {
      return obj.map(sanitize);
    }
    if (obj !== null && typeof obj === 'object') {
      const sanitized: any = {};
      for (const key in obj) {
        sanitized[key] = sanitize(obj[key]);
      }
      return sanitized;
    }
    return obj;
  };

  if (req.body) {
    req.body = sanitize(req.body);
  }
  if (req.query) {
    req.query = sanitize(req.query);
  }
  if (req.params) {
    req.params = sanitize(req.params);
  }

  next();
};

// Audit logging middleware
export const auditLogger: RequestHandler = async (req, res, next) => {
  const startTime = Date.now();
  
  res.on('finish', async () => {
    const duration = Date.now() - startTime;
    const userId = req.user?.userId;
    const ip = req.ip;
    const userAgent = req.headers['user-agent'] || '';
    const method = req.method;
    const path = req.path;
    const statusCode = res.statusCode;
    const success = statusCode < 400;

    // Calculate risk score based on various factors
    let riskScore = 0;
    if (statusCode === 401 || statusCode === 403) riskScore += 3;
    if (statusCode >= 500) riskScore += 2;
    if (method === 'DELETE') riskScore += 1;
    if (path.includes('admin')) riskScore += 2;
    if (!userId) riskScore += 1;

    try {
      await storage.logSecurityEvent({
        userId: userId || null,
        sessionId: req.sessionID || null,
        action: `${method} ${path}`,
        resource: path,
        details: {
          statusCode,
          duration,
          userAgent,
          body: req.body ? Object.keys(req.body) : [],
        },
        ipAddress: ip,
        userAgent,
        success,
        riskScore,
      });
    } catch (error) {
      console.error('Failed to log security event:', error);
    }
  });

  next();
};

// CSRF protection for state-changing operations
export const csrfProtection: RequestHandler = (req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const token = req.headers['x-csrf-token'] || req.body._csrf;
    const sessionToken = req.session?.csrfToken;

    if (!token || !sessionToken || token !== sessionToken) {
      return res.status(403).json({ 
        error: 'CSRF token mismatch. Please refresh the page and try again.' 
      });
    }
  }

  next();
};

// Generate CSRF token
export const generateCSRFToken: RequestHandler = (req, res, next) => {
  if (req.session && !req.session.csrfToken) {
    req.session.csrfToken = randomBytes(32).toString('hex');
  }
  
  if (req.session?.csrfToken) {
    res.locals.csrfToken = req.session.csrfToken;
  }
  next();
};

// Subdomain security middleware
export const subdomainSecurity: RequestHandler = (req, res, next) => {
  const subdomain = req.hostname.split('.')[0];
  const allowedSubdomains = ['www', 'admin', 'portal', 'user'];

  // Log subdomain access attempts
  if (!allowedSubdomains.includes(subdomain)) {
    console.warn(`Unauthorized subdomain access attempt: ${subdomain} from IP: ${req.ip}`);
    return res.status(404).json({ error: 'Subdomain not found' });
  }

  // Set subdomain context
  req.subdomain = subdomain;
  next();
};

// Account lockout protection
export const accountLockoutProtection: RequestHandler = async (req, res, next) => {
  if (req.path.includes('/login') && req.method === 'POST') {
    const { email } = req.body;
    
    if (email) {
      const user = await storage.getUserByEmail(email);
      if (user?.lockedUntil && new Date() < user.lockedUntil) {
        const remainingTime = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
        return res.status(423).json({ 
          error: `Account is locked. Try again in ${remainingTime} minutes.` 
        });
      }
    }
  }

  next();
};

// Extend Express Request type for subdomain
declare global {
  namespace Express {
    interface Request {
      subdomain?: string;
    }
  }
}
