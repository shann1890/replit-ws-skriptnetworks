import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import AdminLayout from "@/components/AdminLayout";
import { DataTable } from "@/components/DataTable";
import { StatusBadge } from "@/components/StatusBadge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { TicketForm } from "@/components/forms/TicketForm";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { MessageSquare, Plus, Search, Filter, AlertCircle, CheckCircle } from "lucide-react";
import type { SupportTicket } from "@shared/schema";

export default function AdminTickets() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tickets, isLoading, error } = useQuery<SupportTicket[]>({
    queryKey: ["/api/tickets"],
    retry: false,
  });

  const { data: users } = useQuery<any[]>({
    queryKey: ["/api/admin/users"],
    retry: false,
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<SupportTicket> }) => {
      await apiRequest("PATCH", `/api/tickets/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      toast({
        title: "Success",
        description: "Ticket updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update ticket",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-destructive">
              <p>Failed to load support tickets. Please try again.</p>
            </div>
          </CardContent>
        </Card>
      </AdminLayout>
    );
  }

  const filteredTickets = (tickets || []).filter((ticket: SupportTicket) => {
    const user = (users || []).find((u: any) => u.id === ticket.userId);
    const userName = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : '';
    
    const matchesSearch = !searchTerm || 
      ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || ticket.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  }) || [];

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return <span className="priority-high">High</span>;
      case 'medium':
        return <span className="priority-medium">Medium</span>;
      case 'low':
        return <span className="priority-low">Low</span>;
      default:
        return <span className="priority-medium">Medium</span>;
    }
  };

  const columns = [
    {
      key: "title",
      header: "Ticket",
      accessor: (ticket: SupportTicket) => (
        <div>
          <p className="font-medium" data-testid={`ticket-title-${ticket.id}`}>
            #{ticket.id} - {ticket.title}
          </p>
          <p className="text-sm text-muted-foreground truncate max-w-xs">
            {ticket.description}
          </p>
        </div>
      ),
    },
    {
      key: "user",
      header: "User",
      accessor: (ticket: SupportTicket) => {
        const user = (users || []).find((u: any) => u.id === ticket.userId);
        return (
          <div>
            <p className="font-medium" data-testid={`ticket-user-${ticket.id}`}>
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || 'Unknown User'
              }
            </p>
            <p className="text-sm text-muted-foreground">
              {user?.email}
            </p>
          </div>
        );
      },
    },
    {
      key: "priority",
      header: "Priority",
      accessor: (ticket: SupportTicket) => (
        <div data-testid={`ticket-priority-${ticket.id}`}>
          {getPriorityBadge(ticket.priority || 'medium')}
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      accessor: (ticket: SupportTicket) => (
        <StatusBadge status={ticket.status || 'open'} data-testid={`ticket-status-${ticket.id}`} />
      ),
    },
    {
      key: "createdAt",
      header: "Created",
      accessor: (ticket: SupportTicket) => (
        <span className="text-sm text-muted-foreground" data-testid={`ticket-created-${ticket.id}`}>
          {new Date(ticket.createdAt!).toLocaleDateString()}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      accessor: (ticket: SupportTicket) => (
        <div className="flex items-center space-x-2">
          <Select
            value={ticket.status || 'open'}
            onValueChange={(value) => updateTicketMutation.mutate({ 
              id: ticket.id, 
              updates: { status: value, updatedAt: new Date() } 
            })}
          >
            <SelectTrigger className="w-32" data-testid={`select-ticket-status-${ticket.id}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text" data-testid="title-tickets">Support Tickets</h1>
            <p className="text-muted-foreground mt-2">Manage and respond to customer support requests</p>
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="glow-effect" data-testid="button-create-ticket">
                <Plus className="mr-2 h-4 w-4" />
                New Ticket
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Support Ticket</DialogTitle>
              </DialogHeader>
              <TicketForm 
                users={users || []}
                onSuccess={() => {
                  setIsCreateModalOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold text-primary" data-testid="stat-total-tickets">
                    {(tickets || []).length}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Open</p>
                  <p className="text-2xl font-bold text-destructive" data-testid="stat-open-tickets">
                    {(tickets || []).filter((t: SupportTicket) => t.status === 'open').length}
                  </p>
                </div>
                <AlertCircle className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold text-warning" data-testid="stat-progress-tickets">
                    {(tickets || []).filter((t: SupportTicket) => t.status === 'in-progress').length}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Resolved</p>
                  <p className="text-2xl font-bold text-success" data-testid="stat-resolved-tickets">
                    {(tickets || []).filter((t: SupportTicket) => t.status === 'resolved').length}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="security-card">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tickets..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-tickets"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48" data-testid="select-ticket-status-filter">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-48" data-testid="select-ticket-priority-filter">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priorities</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tickets Table */}
        <Card className="security-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5" />
              <span>Support Tickets ({filteredTickets.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <DataTable 
              data={filteredTickets}
              columns={columns}
              emptyMessage="No support tickets found"
              data-testid="table-tickets"
            />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
