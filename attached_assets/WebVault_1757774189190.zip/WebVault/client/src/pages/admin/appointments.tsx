import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import AdminLayout from "@/components/AdminLayout";
import { DataTable } from "@/components/DataTable";
import { StatusBadge } from "@/components/StatusBadge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import AppointmentForm from "@/components/forms/AppointmentForm";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Calendar, Plus, Search, Filter, Clock, DollarSign } from "lucide-react";
import type { Appointment } from "@shared/schema";

export default function AdminAppointments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: appointments, isLoading, error } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
    retry: false,
  });

  const { data: users } = useQuery<any[]>({
    queryKey: ["/api/admin/users"],
    retry: false,
  });

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Appointment> }) => {
      await apiRequest("PATCH", `/api/appointments/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Success",
        description: "Appointment updated successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update appointment",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-destructive">
              <p>Failed to load appointments. Please try again.</p>
            </div>
          </CardContent>
        </Card>
      </AdminLayout>
    );
  }

  const filteredAppointments = (appointments || []).filter((appointment: Appointment) => {
    const user = (users || []).find((u: any) => u.id === appointment.userId);
    const userName = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : '';
    
    const matchesSearch = !searchTerm || 
      appointment.serviceType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || appointment.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  }) || [];

  const columns = [
    {
      key: "user",
      header: "Client",
      accessor: (appointment: Appointment) => {
        const user = (users || []).find((u: any) => u.id === appointment.userId);
        return (
          <div>
            <p className="font-medium" data-testid={`appointment-client-${appointment.id}`}>
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}`
                : user?.email || 'Unknown User'
              }
            </p>
            <p className="text-sm text-muted-foreground">
              {user?.email}
            </p>
          </div>
        );
      },
    },
    {
      key: "serviceType",
      header: "Service",
      accessor: (appointment: Appointment) => (
        <div>
          <p className="font-medium" data-testid={`appointment-service-${appointment.id}`}>
            {appointment.serviceType}
          </p>
          {appointment.description && (
            <p className="text-sm text-muted-foreground truncate max-w-xs">
              {appointment.description}
            </p>
          )}
        </div>
      ),
    },
    {
      key: "scheduledDate",
      header: "Scheduled",
      accessor: (appointment: Appointment) => (
        <div>
          <p className="font-medium" data-testid={`appointment-date-${appointment.id}`}>
            {new Date(appointment.scheduledDate).toLocaleDateString()}
          </p>
          <p className="text-sm text-muted-foreground">
            {new Date(appointment.scheduledDate).toLocaleTimeString()}
          </p>
        </div>
      ),
    },
    {
      key: "status",
      header: "Status",
      accessor: (appointment: Appointment) => (
        <StatusBadge status={appointment.status || 'scheduled'} data-testid={`appointment-status-${appointment.id}`} />
      ),
    },
    {
      key: "estimatedPrice",
      header: "Price",
      accessor: (appointment: Appointment) => (
        <span className="font-medium text-success" data-testid={`appointment-price-${appointment.id}`}>
          ${appointment.estimatedPrice || '0.00'}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      accessor: (appointment: Appointment) => (
        <Select
          value={appointment.status || 'scheduled'}
          onValueChange={(value) => updateAppointmentMutation.mutate({ 
            id: appointment.id, 
            updates: { status: value } 
          })}
        >
          <SelectTrigger className="w-32" data-testid={`select-appointment-status-${appointment.id}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="scheduled">Scheduled</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="in-progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      ),
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text" data-testid="title-appointments">Appointment Management</h1>
            <p className="text-muted-foreground mt-2">Schedule and manage client appointments</p>
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="glow-effect" data-testid="button-create-appointment">
                <Plus className="mr-2 h-4 w-4" />
                New Appointment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Appointment</DialogTitle>
              </DialogHeader>
              <AppointmentForm 
                users={users || []}
                onSuccess={() => {
                  setIsCreateModalOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold text-primary" data-testid="stat-total-appointments">
                    {(appointments || []).length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Upcoming</p>
                  <p className="text-2xl font-bold text-accent" data-testid="stat-upcoming-appointments">
                    {(appointments || []).filter((a: Appointment) => 
                      new Date(a.scheduledDate) > new Date() && a.status === 'scheduled'
                    ).length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold text-success" data-testid="stat-completed-appointments">
                    {(appointments || []).filter((a: Appointment) => a.status === 'completed').length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Revenue</p>
                  <p className="text-2xl font-bold text-warning" data-testid="stat-appointment-revenue">
                    ${(appointments || []).reduce((sum: number, a: Appointment) => 
                      sum + (parseFloat(a.estimatedPrice || '0')), 0
                    ).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="security-card">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search appointments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-appointments"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48" data-testid="select-appointment-status-filter">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Appointments Table */}
        <Card className="security-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Appointments ({filteredAppointments.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <DataTable 
              data={filteredAppointments}
              columns={columns}
              emptyMessage="No appointments found"
              data-testid="table-appointments"
            />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
