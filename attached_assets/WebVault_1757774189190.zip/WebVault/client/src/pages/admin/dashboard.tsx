import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import AdminLayout from "@/components/AdminLayout";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import { 
  Users, 
  Calendar, 
  MessageSquare, 
  Shield, 
  Activity,
  AlertTriangle,
  Clock,
  CheckCircle
} from "lucide-react";

interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  pendingUsers: number;
  totalAppointments: number;
  upcomingAppointments: number;
  totalTickets: number;
  openTickets: number;
  resolvedTickets: number;
  recentActivity: Array<{
    id: number;
    action: string;
    user: string;
    timestamp: string;
    status: 'success' | 'warning' | 'error';
  }>;
}

export default function AdminDashboard() {
  const { toast } = useToast();

  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
    retry: false,
  });

  const { data: appointments, isLoading: appointmentsLoading } = useQuery({
    queryKey: ["/api/appointments"],
    retry: false,
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/tickets"],
    retry: false,
  });

  const { data: auditLogs, isLoading: auditLoading } = useQuery({
    queryKey: ["/api/admin/audit-logs"],
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    const handleError = (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    };

    if (users?.error || appointments?.error || tickets?.error || auditLogs?.error) {
      handleError(new Error("401: Unauthorized"));
    }
  }, [users, appointments, tickets, auditLogs, toast]);

  if (usersLoading || appointmentsLoading || ticketsLoading || auditLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </AdminLayout>
    );
  }

  // Calculate stats
  const stats = {
    totalUsers: users?.length || 0,
    activeUsers: users?.filter((u: any) => u.status === 'active')?.length || 0,
    pendingUsers: users?.filter((u: any) => u.status === 'pending')?.length || 0,
    totalAppointments: appointments?.length || 0,
    upcomingAppointments: appointments?.filter((a: any) => new Date(a.scheduledDate) > new Date())?.length || 0,
    totalTickets: tickets?.length || 0,
    openTickets: tickets?.filter((t: any) => t.status === 'open')?.length || 0,
    resolvedTickets: tickets?.filter((t: any) => t.status === 'resolved')?.length || 0,
  };

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text" data-testid="title-dashboard">Admin Dashboard</h1>
            <p className="text-muted-foreground mt-2">Monitor and manage your Autoskript Technology platform</p>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-success" />
            <span className="text-sm text-muted-foreground">System Secure</span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="security-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary" data-testid="stat-total-users">{stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-success" data-testid="stat-active-users">{stats.activeUsers} active</span> · 
                <span className="text-warning ml-1" data-testid="stat-pending-users">{stats.pendingUsers} pending</span>
              </p>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Appointments</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="stat-total-appointments">{stats.totalAppointments}</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-accent" data-testid="stat-upcoming-appointments">{stats.upcomingAppointments} upcoming</span>
              </p>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Support Tickets</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-warning" data-testid="stat-total-tickets">{stats.totalTickets}</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-destructive" data-testid="stat-open-tickets">{stats.openTickets} open</span> · 
                <span className="text-success ml-1" data-testid="stat-resolved-tickets">{stats.resolvedTickets} resolved</span>
              </p>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Security Score</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success" data-testid="stat-security-score">98%</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-success">Excellent security posture</span>
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity and System Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Activity */}
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-accent" />
                <span>Recent Activity</span>
                <Badge variant="outline" className="ml-auto">Live</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {auditLogs?.slice(0, 5).map((log: any, index: number) => (
                  <div key={log.id} className="flex items-center space-x-3 p-3 bg-background rounded-lg border border-border">
                    <div className={`w-2 h-2 rounded-full ${
                      log.success ? 'bg-success' : log.riskScore > 2 ? 'bg-destructive' : 'bg-warning'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate" data-testid={`activity-action-${index}`}>
                        {log.action}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid={`activity-time-${index}`}>
                        {new Date(log.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground" data-testid={`activity-ip-${index}`}>
                      {log.ipAddress}
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8 text-muted-foreground">
                    <Activity className="h-8 w-8 mx-auto mb-2" />
                    <p>No recent activity</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* System Status */}
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-success" />
                <span>System Status</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium">Database Connection</span>
                  </div>
                  <Badge className="status-active" data-testid="status-database">Online</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-4 w-4 text-success" />
                    <span className="text-sm font-medium">Authentication Service</span>
                  </div>
                  <Badge className="status-active" data-testid="status-auth">Active</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <Clock className="h-4 w-4 text-warning" />
                    <span className="text-sm font-medium">Backup System</span>
                  </div>
                  <Badge className="status-pending" data-testid="status-backup">Scheduled</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                  <div className="flex items-center space-x-3">
                    <AlertTriangle className="h-4 w-4 text-warning" />
                    <span className="text-sm font-medium">Security Scan</span>
                  </div>
                  <Badge className="status-pending" data-testid="status-security-scan">In Progress</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
