import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import UserLayout from "@/components/UserLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useEffect } from "react";
import { Link } from "wouter";
import { 
  Calendar, 
  MessageSquare, 
  Clock, 
  Plus,
  Bell,
  Shield,
  Activity,
  User
} from "lucide-react";
import type { Appointment, SupportTicket, Notification } from "@shared/schema";

export default function UserDashboard() {
  const { toast } = useToast();

  const { data: appointments, isLoading: appointmentsLoading, error: appointmentsError } = useQuery({
    queryKey: ["/api/appointments"],
    retry: false,
  });

  const { data: tickets, isLoading: ticketsLoading, error: ticketsError } = useQuery({
    queryKey: ["/api/tickets"],
    retry: false,
  });

  const { data: notifications, isLoading: notificationsLoading } = useQuery({
    queryKey: ["/api/notifications"],
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    const handleError = (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    };

    if (appointmentsError || ticketsError) {
      handleError(appointmentsError || ticketsError);
    }
  }, [appointmentsError, ticketsError, toast]);

  if (appointmentsLoading || ticketsLoading || notificationsLoading) {
    return (
      <UserLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </UserLayout>
    );
  }

  const upcomingAppointments = appointments?.filter((a: Appointment) => 
    new Date(a.scheduledDate) > new Date() && a.status !== 'cancelled'
  ).slice(0, 3) || [];

  const openTickets = tickets?.filter((t: SupportTicket) => 
    t.status === 'open' || t.status === 'in-progress'
  ).slice(0, 3) || [];

  const recentNotifications = notifications?.slice(0, 3) || [];

  return (
    <UserLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text" data-testid="title-dashboard">Dashboard</h1>
            <p className="text-muted-foreground mt-2">Welcome to your Autoskript Technology portal</p>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-success" />
            <span className="text-sm text-muted-foreground">Account Active</span>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Appointments</p>
                  <p className="text-2xl font-bold text-primary" data-testid="stat-user-appointments">
                    {appointments?.length || 0}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Upcoming</p>
                  <p className="text-2xl font-bold text-accent" data-testid="stat-upcoming-appointments">
                    {upcomingAppointments.length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Support Tickets</p>
                  <p className="text-2xl font-bold text-warning" data-testid="stat-user-tickets">
                    {tickets?.length || 0}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Open Tickets</p>
                  <p className="text-2xl font-bold text-destructive" data-testid="stat-open-tickets">
                    {openTickets.length}
                  </p>
                </div>
                <Activity className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Appointments */}
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-accent" />
                  <span>Upcoming Appointments</span>
                </div>
                <Link href="/appointments">
                  <Button variant="link" size="sm" className="text-accent" data-testid="link-view-all-appointments">
                    View All
                  </Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingAppointments.length > 0 ? (
                  upcomingAppointments.map((appointment: Appointment, index: number) => (
                    <div key={appointment.id} className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                      <div className="flex-1">
                        <p className="font-medium" data-testid={`appointment-service-${index}`}>
                          {appointment.serviceType}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`appointment-date-${index}`}>
                          {new Date(appointment.scheduledDate).toLocaleDateString()} at {' '}
                          {new Date(appointment.scheduledDate).toLocaleTimeString()}
                        </p>
                        {appointment.estimatedPrice && (
                          <p className="text-sm text-success font-medium" data-testid={`appointment-price-${index}`}>
                            ${appointment.estimatedPrice}
                          </p>
                        )}
                      </div>
                      <StatusBadge status={appointment.status || 'scheduled'} />
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-8 w-8 mx-auto mb-2" />
                    <p>No upcoming appointments</p>
                    <Link href="/appointments">
                      <Button variant="link" size="sm" className="mt-2" data-testid="link-schedule-appointment">
                        Schedule your first appointment
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Support Tickets */}
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5 text-warning" />
                  <span>Support Tickets</span>
                  {openTickets.length > 0 && (
                    <Badge variant="destructive" data-testid="badge-open-tickets">
                      {openTickets.length} Open
                    </Badge>
                  )}
                </div>
                <Link href="/tickets">
                  <Button variant="link" size="sm" className="text-accent" data-testid="link-view-all-tickets">
                    View All
                  </Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tickets?.slice(0, 3).map((ticket: SupportTicket, index: number) => (
                  <div key={ticket.id} className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                    <div className="flex-1">
                      <p className="font-medium" data-testid={`ticket-title-${index}`}>
                        #{ticket.id} - {ticket.title}
                      </p>
                      <p className="text-sm text-muted-foreground truncate" data-testid={`ticket-description-${index}`}>
                        {ticket.description}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1" data-testid={`ticket-created-${index}`}>
                        Created: {new Date(ticket.createdAt!).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <StatusBadge status={ticket.status || 'open'} />
                      <span className={`text-xs px-2 py-1 rounded ${
                        ticket.priority === 'high' ? 'priority-high' :
                        ticket.priority === 'medium' ? 'priority-medium' : 'priority-low'
                      }`} data-testid={`ticket-priority-${index}`}>
                        {ticket.priority || 'medium'}
                      </span>
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-8 w-8 mx-auto mb-2" />
                    <p>No support tickets</p>
                    <Link href="/tickets">
                      <Button variant="link" size="sm" className="mt-2" data-testid="link-create-ticket">
                        Create your first ticket
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications */}
        <Card className="security-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-primary" />
              <span>Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentNotifications.length > 0 ? (
                recentNotifications.map((notification: Notification, index: number) => (
                  <div key={notification.id} className="flex items-start space-x-3 p-4 bg-background rounded-lg border border-border">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center mt-1">
                      <Bell className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium" data-testid={`notification-title-${index}`}>
                        {notification.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1" data-testid={`notification-message-${index}`}>
                        {notification.message}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2" data-testid={`notification-date-${index}`}>
                        {new Date(notification.createdAt!).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs" data-testid={`notification-type-${index}`}>
                      {notification.type}
                    </Badge>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2" />
                  <p>No notifications</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="security-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5 text-accent" />
              <span>Quick Actions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Link href="/appointments">
                <Button className="w-full justify-start h-auto p-4" variant="outline" data-testid="button-schedule-appointment">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Schedule Appointment</p>
                      <p className="text-sm text-muted-foreground">Book a consultation or service</p>
                    </div>
                  </div>
                </Button>
              </Link>

              <Link href="/tickets">
                <Button className="w-full justify-start h-auto p-4" variant="outline" data-testid="button-create-support-ticket">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-warning" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Create Support Ticket</p>
                      <p className="text-sm text-muted-foreground">Get help with issues</p>
                    </div>
                  </div>
                </Button>
              </Link>

              <Link href="/profile">
                <Button className="w-full justify-start h-auto p-4" variant="outline" data-testid="button-update-profile">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                      <User className="h-5 w-5 text-accent" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium">Update Profile</p>
                      <p className="text-sm text-muted-foreground">Manage your information</p>
                    </div>
                  </div>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </UserLayout>
  );
}
