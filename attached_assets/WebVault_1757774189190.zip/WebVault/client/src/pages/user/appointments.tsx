import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import UserLayout from "@/components/UserLayout";
import { StatusBadge } from "@/components/StatusBadge";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import AppointmentForm from "@/components/forms/AppointmentForm";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Calendar, Plus, Search, Filter, Clock, DollarSign } from "lucide-react";
import type { Appointment } from "@shared/schema";

export default function UserAppointments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: appointments, isLoading, error } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
    retry: false,
  });

  const cancelAppointmentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/appointments/${id}`, { status: 'cancelled' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: "Success",
        description: "Appointment cancelled successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to cancel appointment",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <UserLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner />
        </div>
      </UserLayout>
    );
  }

  if (error) {
    return (
      <UserLayout>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-destructive">
              <p>Failed to load appointments. Please try again.</p>
            </div>
          </CardContent>
        </Card>
      </UserLayout>
    );
  }

  const filteredAppointments = (appointments || []).filter((appointment: Appointment) => {
    const matchesSearch = !searchTerm || 
      appointment.serviceType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      appointment.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || appointment.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  }) || [];

  const upcomingAppointments = filteredAppointments.filter((a: Appointment) => 
    new Date(a.scheduledDate) > new Date() && a.status !== 'cancelled'
  );

  const pastAppointments = filteredAppointments.filter((a: Appointment) => 
    new Date(a.scheduledDate) <= new Date() || a.status === 'completed' || a.status === 'cancelled'
  );

  return (
    <UserLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold gradient-text" data-testid="title-appointments">My Appointments</h1>
            <p className="text-muted-foreground mt-2">View and manage your scheduled appointments</p>
          </div>
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogTrigger asChild>
              <Button className="glow-effect" data-testid="button-schedule-appointment">
                <Plus className="mr-2 h-4 w-4" />
                Schedule Appointment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Schedule New Appointment</DialogTitle>
              </DialogHeader>
              <AppointmentForm 
                onSuccess={() => {
                  setIsCreateModalOpen(false);
                  queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
                }}
              />
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Appointments</p>
                  <p className="text-2xl font-bold text-primary" data-testid="stat-total-user-appointments">
                    {(appointments || []).length}
                  </p>
                </div>
                <Calendar className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Upcoming</p>
                  <p className="text-2xl font-bold text-accent" data-testid="stat-upcoming-user-appointments">
                    {upcomingAppointments.length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
                  <p className="text-2xl font-bold text-success" data-testid="stat-total-spent">
                    ${(appointments || []).filter((a: Appointment) => a.status === 'completed')
                      .reduce((sum: number, a: Appointment) => sum + (parseFloat(a.estimatedPrice || '0')), 0)
                      .toFixed(2)}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="security-card">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search appointments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-appointments"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48" data-testid="select-appointment-filter">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Appointments */}
        {upcomingAppointments.length > 0 && (
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-accent" />
                <span>Upcoming Appointments</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {upcomingAppointments.map((appointment: Appointment, index: number) => (
                  <div key={appointment.id} className="p-4 bg-background rounded-lg border border-border hover:border-accent/50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium" data-testid={`upcoming-appointment-service-${index}`}>
                          {appointment.serviceType}
                        </h4>
                        <p className="text-sm text-muted-foreground" data-testid={`upcoming-appointment-date-${index}`}>
                          {new Date(appointment.scheduledDate).toLocaleDateString()} at {' '}
                          {new Date(appointment.scheduledDate).toLocaleTimeString()}
                        </p>
                      </div>
                      <StatusBadge status={appointment.status || 'scheduled'} />
                    </div>
                    
                    {appointment.description && (
                      <p className="text-sm text-muted-foreground mb-3" data-testid={`upcoming-appointment-description-${index}`}>
                        {appointment.description}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      {appointment.estimatedPrice && (
                        <span className="text-success font-medium" data-testid={`upcoming-appointment-price-${index}`}>
                          ${appointment.estimatedPrice}
                        </span>
                      )}
                      
                      {appointment.status === 'scheduled' && (
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => cancelAppointmentMutation.mutate(appointment.id)}
                          disabled={cancelAppointmentMutation.isPending}
                          data-testid={`button-cancel-appointment-${index}`}
                        >
                          Cancel
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Past Appointments */}
        {pastAppointments.length > 0 && (
          <Card className="security-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <span>Past Appointments</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pastAppointments.map((appointment: Appointment, index: number) => (
                  <div key={appointment.id} className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                    <div className="flex-1">
                      <p className="font-medium" data-testid={`past-appointment-service-${index}`}>
                        {appointment.serviceType}
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`past-appointment-date-${index}`}>
                        {new Date(appointment.scheduledDate).toLocaleDateString()}
                      </p>
                      {appointment.description && (
                        <p className="text-sm text-muted-foreground truncate max-w-md" data-testid={`past-appointment-description-${index}`}>
                          {appointment.description}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center space-x-3">
                      {appointment.estimatedPrice && (
                        <span className="text-success font-medium" data-testid={`past-appointment-price-${index}`}>
                          ${appointment.estimatedPrice}
                        </span>
                      )}
                      <StatusBadge status={appointment.status || 'scheduled'} />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {filteredAppointments.length === 0 && (
          <Card className="security-card">
            <CardContent className="pt-6">
              <div className="text-center py-12">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No appointments found</h3>
                <p className="text-muted-foreground mb-6">
                  {searchTerm || statusFilter !== "all" 
                    ? "Try adjusting your search or filter criteria"
                    : "Schedule your first appointment to get started"
                  }
                </p>
                <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                  <DialogTrigger asChild>
                    <Button className="glow-effect" data-testid="button-schedule-first-appointment">
                      <Plus className="mr-2 h-4 w-4" />
                      Schedule Appointment
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Schedule New Appointment</DialogTitle>
                    </DialogHeader>
                    <AppointmentForm 
                      onSuccess={() => {
                        setIsCreateModalOpen(false);
                        queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
                      }}
                    />
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </UserLayout>
  );
}
