import { Card, CardContent } from "@/components/ui/card";
import { Code, Shield, Server } from "lucide-react";

export default function ServiceGrid() {
  const services = [
    {
      icon: <Code className="text-primary h-6 w-6" />,
      title: "Web Development",
      description: "Custom web applications with modern frameworks, secure authentication, and responsive design.",
      color: "primary"
    },
    {
      icon: <Shield className="text-accent h-6 w-6" />,
      title: "Cybersecurity",
      description: "Comprehensive security audits, penetration testing, and security implementation consulting.",
      color: "accent"
    },
    {
      icon: <Server className="text-success h-6 w-6" />,
      title: "IT Support",
      description: "24/7 managed IT services, system monitoring, and technical support for your business.",
      color: "success"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {services.map((service, index) => (
        <Card 
          key={index} 
          className="bg-background border-border hover:border-accent transition-colors group hover-lift"
          data-testid={`service-card-${index}`}
        >
          <CardContent className="p-6">
            <div className={`w-12 h-12 bg-${service.color}/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-${service.color}/20 transition-colors`}>
              {service.icon}
            </div>
            <h3 className="text-xl font-semibold mb-3" data-testid={`text-service-title-${index}`}>
              {service.title}
            </h3>
            <p className="text-muted-foreground leading-relaxed" data-testid={`text-service-description-${index}`}>
              {service.description}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
