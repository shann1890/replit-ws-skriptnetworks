import { Card, CardContent } from "@/components/ui/card";
import { Lock, Eye, Shield } from "lucide-react";

export default function SecurityFeatures() {
  const features = [
    {
      icon: <Lock className="text-accent h-6 w-6" />,
      title: "Multi-Factor Authentication",
      description: "TOTP-based MFA with QR code generation and backup codes for enhanced account security.",
      color: "accent"
    },
    {
      icon: <Eye className="text-primary h-6 w-6" />,
      title: "Security Audit Logging",
      description: "Comprehensive logging of all user actions with IP tracking and risk scoring.",
      color: "primary"
    },
    {
      icon: <Shield className="text-success h-6 w-6" />,
      title: "Rate Limiting & CSRF",
      description: "Advanced rate limiting, CSRF protection, and input validation against common attacks.",
      color: "success"
    }
  ];

  return (
    <div className="security-grid">
      {features.map((feature, index) => (
        <Card 
          key={index} 
          className="security-card text-center"
          data-testid={`security-feature-${index}`}
        >
          <CardContent className="p-6 space-y-4">
            <div className={`w-16 h-16 bg-${feature.color}/10 rounded-lg flex items-center justify-center mx-auto`}>
              {feature.icon}
            </div>
            <h3 className="text-lg font-semibold" data-testid={`text-feature-title-${index}`}>
              {feature.title}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-feature-description-${index}`}>
              {feature.description}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
