import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Code, Menu, Shield } from "lucide-react";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  const NavLinks = () => (
    <>
      <button 
        onClick={() => scrollToSection('services')} 
        className="text-muted-foreground hover:text-accent transition-colors"
        data-testid="nav-link-services"
      >
        Services
      </button>
      <button 
        onClick={() => scrollToSection('security')} 
        className="text-muted-foreground hover:text-accent transition-colors"
        data-testid="nav-link-security"
      >
        Security
      </button>
      <button 
        onClick={() => scrollToSection('portals')} 
        className="text-muted-foreground hover:text-accent transition-colors"
        data-testid="nav-link-portals"
      >
        Portals
      </button>
      <a 
        href="#contact" 
        className="text-muted-foreground hover:text-accent transition-colors"
        data-testid="nav-link-contact"
      >
        Contact
      </a>
    </>
  );

  return (
    <nav className="fixed top-0 w-full bg-background/95 backdrop-blur-sm border-b border-border z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <Code className="text-background font-bold h-4 w-4" />
            </div>
            <span className="text-xl font-bold gradient-text" data-testid="brand-name">Autoskript</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavLinks />
          </div>
          
          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-login"
            >
              <Shield className="mr-2 h-4 w-4" />
              Login
            </Button>
            <Button 
              size="sm" 
              className="glow-effect"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-client-portal"
            >
              Client Portal
            </Button>
          </div>

          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent className="bg-card border-border">
                <div className="flex flex-col space-y-6 mt-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                      <Code className="text-background font-bold h-4 w-4" />
                    </div>
                    <span className="text-xl font-bold gradient-text">Autoskript</span>
                  </div>
                  
                  <div className="flex flex-col space-y-4">
                    <NavLinks />
                  </div>
                  
                  <div className="border-t border-border pt-6 space-y-3">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start"
                      onClick={() => {
                        window.location.href = '/api/login';
                        setIsOpen(false);
                      }}
                      data-testid="button-mobile-login"
                    >
                      <Shield className="mr-2 h-4 w-4" />
                      Login
                    </Button>
                    <Button 
                      className="w-full glow-effect"
                      onClick={() => {
                        window.location.href = '/api/login';
                        setIsOpen(false);
                      }}
                      data-testid="button-mobile-portal"
                    >
                      Client Portal
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
