import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

interface StatusBadgeProps {
  status: string;
  variant?: "default" | "secondary" | "destructive" | "outline";
  className?: string;
}

const statusMap: Record<string, { variant: StatusBadgeProps["variant"]; label: string }> = {
  // User statuses
  active: { variant: "default", label: "Active" },
  pending: { variant: "secondary", label: "Pending" },
  inactive: { variant: "outline", label: "Inactive" },
  suspended: { variant: "destructive", label: "Suspended" },
  
  // Appointment statuses
  scheduled: { variant: "default", label: "Scheduled" },
  completed: { variant: "outline", label: "Completed" },
  cancelled: { variant: "destructive", label: "Cancelled" },
  in_progress: { variant: "secondary", label: "In Progress" },
  
  // Ticket statuses
  open: { variant: "default", label: "Open" },
  in_review: { variant: "secondary", label: "In Review" },
  resolved: { variant: "outline", label: "Resolved" },
  closed: { variant: "destructive", label: "Closed" },
  
  // Priority levels
  low: { variant: "outline", label: "Low" },
  medium: { variant: "secondary", label: "Medium" },
  high: { variant: "default", label: "High" },
  critical: { variant: "destructive", label: "Critical" },
};

export function StatusBadge({ status, variant, className }: StatusBadgeProps) {
  const statusConfig = statusMap[status] || { variant: "outline", label: status };
  const badgeVariant = variant || statusConfig.variant;

  return (
    <Badge variant={badgeVariant} className={cn("capitalize", className)}>
      {statusConfig.label}
    </Badge>
  );
}