import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { insertAppointmentSchema } from "@shared/schema";
import { z } from "zod";

const appointmentFormSchema = insertAppointmentSchema.extend({
  scheduledDate: z.string().min(1, "Date is required"),
  scheduledTime: z.string().min(1, "Time is required"),
}).omit({ userId: true });

type AppointmentFormData = z.infer<typeof appointmentFormSchema>;

interface AppointmentFormProps {
  users?: any[];
  onSuccess?: () => void;
}

const serviceTypes = [
  "Web Development Consultation",
  "Security Audit",
  "System Optimization",
  "Network Setup",
  "IT Support",
  "Penetration Testing",
  "Custom Development",
  "Infrastructure Review",
];

export default function AppointmentForm({ users, onSuccess }: AppointmentFormProps) {
  const { toast } = useToast();

  const form = useForm<AppointmentFormData>({
    resolver: zodResolver(appointmentFormSchema),
    defaultValues: {
      serviceType: "",
      description: "",
      scheduledDate: "",
      scheduledTime: "",
      location: "",
      estimatedPrice: "",
    },
  });

  const createAppointmentMutation = useMutation({
    mutationFn: async (data: AppointmentFormData) => {
      const { scheduledDate, scheduledTime, ...rest } = data;
      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      await apiRequest("POST", "/api/appointments", {
        ...rest,
        scheduledDate: scheduledDateTime.toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Appointment scheduled successfully",
      });
      onSuccess?.();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to schedule appointment",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AppointmentFormData) => {
    createAppointmentMutation.mutate(data);
  };

  // Get minimum date (today)
  const today = new Date().toISOString().split('T')[0];

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Label htmlFor="serviceType">Service Type *</Label>
        <Select value={form.watch("serviceType")} onValueChange={(value) => form.setValue("serviceType", value)}>
          <SelectTrigger data-testid="select-service-type">
            <SelectValue placeholder="Select a service" />
          </SelectTrigger>
          <SelectContent>
            {serviceTypes.map((service) => (
              <SelectItem key={service} value={service}>
                {service}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {form.formState.errors.serviceType && (
          <p className="text-destructive text-sm mt-1">
            {form.formState.errors.serviceType.message}
          </p>
        )}
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Please describe your requirements..."
          {...form.register("description")}
          rows={3}
          data-testid="textarea-description"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="scheduledDate">Preferred Date *</Label>
          <Input
            id="scheduledDate"
            type="date"
            min={today}
            {...form.register("scheduledDate")}
            data-testid="input-scheduled-date"
          />
          {form.formState.errors.scheduledDate && (
            <p className="text-destructive text-sm mt-1">
              {form.formState.errors.scheduledDate.message}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="scheduledTime">Preferred Time *</Label>
          <Input
            id="scheduledTime"
            type="time"
            {...form.register("scheduledTime")}
            data-testid="input-scheduled-time"
          />
          {form.formState.errors.scheduledTime && (
            <p className="text-destructive text-sm mt-1">
              {form.formState.errors.scheduledTime.message}
            </p>
          )}
        </div>
      </div>

      <div>
        <Label htmlFor="location">Location/Address</Label>
        <Input
          id="location"
          placeholder="Service location or 'Remote'"
          {...form.register("location")}
          data-testid="input-location"
        />
      </div>

      <div>
        <Label htmlFor="estimatedPrice">Estimated Budget</Label>
        <Input
          id="estimatedPrice"
          type="number"
          step="0.01"
          placeholder="0.00"
          {...form.register("estimatedPrice")}
          data-testid="input-estimated-price"
        />
      </div>

      <div className="flex justify-end space-x-3 pt-6">
        <Button
          type="submit"
          disabled={createAppointmentMutation.isPending}
          className="glow-effect"
          data-testid="button-submit-appointment"
        >
          {createAppointmentMutation.isPending ? 'Scheduling...' : 'Schedule Appointment'}
        </Button>
      </div>
    </form>
  );
}
