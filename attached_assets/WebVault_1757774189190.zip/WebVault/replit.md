# Overview

This is a full-stack web application for Autoskript Technology, providing IT services including web development, cybersecurity, and IT support. The application features a public landing page showcasing services and secure user/admin portals for managing appointments, support tickets, and user accounts. Built with modern web technologies, it emphasizes security, performance, and user experience.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React with TypeScript**: Modern component-based UI built with React 18, using TypeScript for type safety
- **Vite Build System**: Fast development server and optimized production builds
- **Wouter Router**: Lightweight client-side routing for navigation between pages
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Shadcn/UI Components**: Pre-built, accessible UI components with Radix UI primitives
- **React Query**: Server state management and data fetching with caching

## Backend Architecture
- **Express.js**: Node.js web framework handling API routes and middleware
- **TypeScript**: Type-safe server-side development
- **Drizzle ORM**: Type-safe database operations with PostgreSQL
- **Session-based Authentication**: Secure session management with Replit Auth integration
- **RESTful API Design**: Standard HTTP methods for CRUD operations

## Database Design
- **PostgreSQL with Neon**: Cloud-hosted PostgreSQL database
- **Drizzle Schema**: Type-safe database schema definitions
- **Role-based Access Control**: Users, roles, and permissions system
- **Audit Logging**: Security event tracking and monitoring
- **Session Storage**: Database-backed session management

## Security Implementation
- **Multi-Factor Authentication**: TOTP-based MFA with backup codes
- **Rate Limiting**: Configurable rate limits for different endpoint types
- **CSRF Protection**: Cross-site request forgery prevention
- **Input Sanitization**: XSS and injection attack prevention
- **Security Headers**: Helmet.js for HTTP security headers
- **Account Lockout**: Brute force attack protection
- **Audit Trail**: Comprehensive security event logging

## Application Structure
- **Subdomain Routing**: Role-based access through subdomain configuration
- **Modular Middleware**: Composable security, authentication, and logging middleware
- **Shared Schema**: Common type definitions between frontend and backend
- **Component Libraries**: Reusable UI components with consistent design patterns

## External Dependencies

- **Neon Database**: PostgreSQL hosting and connection pooling
- **Replit Auth**: OAuth authentication provider integration
- **Radix UI**: Accessible component primitives for UI library
- **Google Fonts**: Web fonts (Fira Code, DM Sans, Architects Daughter)
- **React Query**: Data fetching and state management
- **Helmet.js**: Security middleware for Express
- **bcryptjs**: Password hashing and verification
- **jsonwebtoken**: JWT token generation and validation
- **express-rate-limit**: API rate limiting middleware